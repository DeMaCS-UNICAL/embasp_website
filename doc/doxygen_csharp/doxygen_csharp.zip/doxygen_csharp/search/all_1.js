var searchData=
[
  ['base_12',['base',['../namespacebase.html',1,'']]]
];
