var searchData=
[
  ['base_212',['base',['../namespacebase.html',1,'']]]
];
